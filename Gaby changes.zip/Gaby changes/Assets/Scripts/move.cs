using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    //Speeds
    float horSpeed = 8f;
    float rotSpeed = 350f;

    // Horizontal boundary
    float shipBounRadX = 1.3f;

    //Z axis variable
    float rotz = 0f;


    // Vertical boundary
    //float shipBounRadY = 4.3f;

    // Vertical speed
    //float verSpeed = 3f;

	
    Vector3 lastPos;
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {


        // Z axis rotation
        rotz += Input.GetAxis("Horizontal") * rotSpeed * Time.deltaTime;
        rotz = Mathf.Clamp(rotz, -68.9f, 68.9f);//sets the min and max values for z axis rotation
        transform.localEulerAngles = new Vector3(0, 0, rotz);




        // X axis movement
        Vector3 posx = transform.position;
        posx.x += Input.GetAxis("Horizontal") * horSpeed * Time.deltaTime;

        // Horizontal screen boundaries
        float screenRatio = (float)Screen.width / (float)Screen.height;
        float widthOrtho = Camera.main.orthographicSize * screenRatio;

        if (posx.x + shipBounRadX > widthOrtho)
        {
            posx.x = widthOrtho - shipBounRadX;
        }
        if (posx.x - shipBounRadX < -widthOrtho)
        {
            posx.x = -widthOrtho + shipBounRadX;
        }
        transform.position = posx;
        transform.position = new Vector3(transform.position.x, (.5f * Mathf.Pow(transform.position.x, 2)) - 1.7f, transform.position.z);//functions moves along parabola
        lastPos = posx;

        //Vertical component in case we need it 
        /*
        // Y axis movement
        Vector3 posy = transform.position;
        Vector3 velocity = new Vector3(0, Input.GetAxis("Vertical") * verSpeed * Time.deltaTime, 0);
        posy += rot * velocity;

        // Vertical screen boundaries 
        if (posy.y + shipBounRadY > Camera.main.orthographicSize)
        {
            posy.y = Camera.main.orthographicSize - shipBounRadY;
        }
        if (posy.y - shipBounRadY < -Camera.main.orthographicSize)
        {
            posy.y = -Camera.main.orthographicSize + shipBounRadY;
        }
        transform.position = posy;
        */

    }
	
}
