using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallmove : MonoBehaviour
{
    public float speed = 2;
    private Vector3 endPosition = new Vector3(0, -1.89f, 0);

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position != endPosition)//object moves until it reaches the end position
        {
            transform.position = Vector3.MoveTowards(transform.position, endPosition, speed * Time.deltaTime);//moving wall in y direction
        }
        else
        {
            scorekeeper.scoreval += 1;//when a wall is destroyed the score increases by 1
            Destroy(gameObject);
        }

        transform.localScale = transform.localScale + new Vector3(.72f * Time.deltaTime, .72f * Time.deltaTime, 0); //wall object increases in size as it moves
    }

    void OnTriggerEnter2D(Collider2D col)
	{
		Destroy(gameObject);
		
	}
}
