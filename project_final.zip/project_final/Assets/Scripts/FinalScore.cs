﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FinalScore : MonoBehaviour
{
    Text score;

    void Start()
    {
        score = GetComponent<Text>();
        score.text = "Final Score: " + scorekeeper.scoreval;//displays the final score of the game
    }
}
