using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class move_gyro : MonoBehaviour
{
	AudioSource source;
    Rigidbody2D rb;
    float dirX;
    float moveSpeed = 13f;
    float rotSpeed = 494f;
    float rotz = 0f;
	int count = 0;
	
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
	    source = GetComponent<AudioSource>();
    }

    void Update()
    {
        //z axis rotation
        rotz += Input.acceleration.x * rotSpeed * Time.deltaTime;
        rotz = Mathf.Clamp(rotz, -55f, 55f);
        transform.rotation = Quaternion.Euler(0, 0, rotz);
    }

    void FixedUpdate()
    {
        //x axis movement
	    dirX = Input.acceleration.x * moveSpeed;
	    transform.position = new Vector2(Mathf.Clamp(transform.position.x, -7.5f, 7.5f), transform.position.y);
        rb.velocity = new Vector2(dirX, 0f);
    }
	
	void OnTriggerEnter2D(Collider2D col)
	{
		
		if (count >= 2)//when 3 collisions have occured
		{
			count = 0;
			Destroy(gameObject);
			SceneManager.LoadScene("Game Over");//displays game over screen
		}
		count++;
		source.Play();
	}

}
