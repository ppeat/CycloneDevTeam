using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class rightmove : MonoBehaviour
{

    public float speed = 2f;
    private Vector3 endPosition = new Vector3(1.67f, -0.46f, 0);
    public static int check = 0;

    void Start()
    {
        transform.rotation = Quaternion.Euler(0, 0, 69.26f);//set initial rotation of object
        this.transform.position = new Vector3(.06f, 2.4f, 0);//sets initial position of object
    }

    void FixedUpdate()
    {
        if (transform.position != endPosition)//only moves when the wall hasn't reached end position
        {
            transform.position = Vector3.MoveTowards(transform.position, endPosition, speed * Time.deltaTime);//moving wall in y direction
        }
        else
        {
            scorekeeper.scoreval += 1;//when a wall is destroyed the score increases by 1
            Destroy(gameObject);
        }

        transform.localScale = transform.localScale + new Vector3(.6f * Time.deltaTime, .6f * Time.deltaTime, 0); //wall object increases in size as it moves


    }

    void OnTriggerEnter2D(Collider2D col) //function is called when wall collides with another object
    {
        if (col.name == "ship")//checks that the collision was with the ship object
        {
            check = 1;
            Destroy(gameObject);
            lives.health -= 1;
        }
    }
}