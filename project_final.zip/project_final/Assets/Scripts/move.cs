using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move : MonoBehaviour
{
    //Speeds
    float horSpeed = 8f;
    float rotSpeed = 350f;

    // Horizontal boundary
   float shipBounRadX = 1.3f;

    //Z axis variable
    float rotz = 0f;
	
    void Update()
    {
        // Z axis rotation
        rotz += Input.GetAxis("Horizontal") * rotSpeed * Time.deltaTime;
        rotz = Mathf.Clamp(rotz, -68.9f, 68.9f);//sets the min and max values for z axis rotation
        transform.localEulerAngles = new Vector3(0, 0, rotz);

	}
    void FixedUpdate()
    {
        // X axis movement
        Vector3 posx = transform.position;
        posx.x += Input.GetAxis("Horizontal") * horSpeed * Time.deltaTime;

        // Horizontal screen boundaries
        float screenRatio = (float)Screen.width / (float)Screen.height;
        float widthOrtho = Camera.main.orthographicSize * screenRatio;

        if (posx.x + shipBounRadX > widthOrtho)
        {
            posx.x = widthOrtho - shipBounRadX;
        }
        if (posx.x - shipBounRadX < -widthOrtho)
        {
            posx.x = -widthOrtho + shipBounRadX;
        }

        transform.position = posx;
        transform.position = new Vector3(transform.position.x, (.7f * Mathf.Pow(transform.position.x, 2)) - 1.7f, transform.position.z);//ship moves in parabola shape
        Vector3 lastPos = posx;
    }
	
}
