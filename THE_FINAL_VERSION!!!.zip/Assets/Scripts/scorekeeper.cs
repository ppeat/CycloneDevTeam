﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class scorekeeper : MonoBehaviour
{
    public static int scoreval;
    Text score;

    void Start()
    {
        scoreval = 0;
        score = GetComponent<Text>();
    }

    void Update()
    {
        score.text = "Score: " + scoreval; //displays value of score
    }
}
