using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class End : MonoBehaviour
{
	public void doExitGame()
	{
		Application.Quit();//quits the game
	}
}