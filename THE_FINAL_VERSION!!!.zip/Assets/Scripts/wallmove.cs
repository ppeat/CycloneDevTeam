using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallmove : MonoBehaviour
{
    public float speed = 2;
    private Vector3 endPosition = new Vector3(0, -1.79f, 0);
    public static int check = 0;

    void Start()
    {
            
    }

    void FixedUpdate()
    {
        if (transform.position != endPosition)//only moves when the wall hasn't reached end position
        {
            transform.position=Vector3.MoveTowards(transform.position, endPosition, speed * Time.deltaTime);//moving wall in y direction
        }
        else
        {
            scorekeeper.scoreval += 1;//when a wall is destroyed the score increases by 1
            Destroy(gameObject);
        }

        transform.localScale = transform.localScale + new Vector3(.6f * Time.deltaTime, .6f * Time.deltaTime, 0); //wall object increases in size as it moves
    }

    void OnTriggerEnter2D(Collider2D col) //function is called when wall collides with another object
    {

        if (col.name == "ship")//checks that the collision was with the ship object
        {
            check = 1;
            Destroy(gameObject);
            lives.health -= 1;
        }
    }


}
