using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallmove : MonoBehaviour
{
    public float speed = 2;
    private Vector3 endPosition = new Vector3(0, -1.79f, 0);
    public static int check = 0;

    // Start is called before the first frame update
    void Start()
    {
            
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (transform.position != endPosition)
        {
            transform.position=Vector3.MoveTowards(transform.position, endPosition, speed * Time.deltaTime);//moving wall in y direction
        }
        else
        {
            scorekeeper.scoreval += 1;//when a wall is destroyed the score increases by 1
            Destroy(gameObject);
        }

        transform.localScale = transform.localScale + new Vector3(.6f * Time.deltaTime, .6f * Time.deltaTime, 0); //wall object increases in size as it moves
    }

    void OnTriggerEnter2D(Collider2D col)
    {

        if (col.name == "ship")
        {
            check = 1;
            Destroy(gameObject);
            lives.health -= 1;
        }
    }


}
