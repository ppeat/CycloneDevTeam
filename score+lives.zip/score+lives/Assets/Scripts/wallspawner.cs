using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallspawner : MonoBehaviour
{

    public GameObject wallcenter;
    public GameObject wallleft;
    public GameObject wallright;
    public float maxpos = 2.2f;
    float timer;
    float delay;//how often wall is spawned
    int rannum;

    // Start is called before the first frame update
    void Start()
    {
        timer = delay;
    }

    void center()
    {
        {
            Vector3 centerpos = new Vector3(0f, transform.position.y, transform.position.z);//location of the wall
            Instantiate(wallcenter, centerpos, transform.rotation);//spawns a wall in the center
        }
    }

    void left()
    {
        Vector3 leftpos = new Vector3(-.05f, transform.position.y, transform.position.z); //location of the wall
        Instantiate(wallleft, leftpos, transform.rotation); //spawns a wall on the left
    }

    void right()
    {
        Vector3 rightpos = new Vector3(-.05f, transform.position.y, transform.position.z); //location of the wall
        Instantiate(wallright, rightpos, transform.rotation); //spawns a wall on the right
    }


    // Update is called once per frame
    void Update()
    {
        rannum = Random.Range(1, 5);
        delay = Random.Range(.8f, 2f);//generates a random number which dictates how often the wall functions are called
        timer -= Time.deltaTime;
        if (timer <= 0) //when the timer reaches zero a wall is spawned
        {
            switch (rannum)//depending of the value of rannum the function for one of the wall position's is called
            {
                case 1:
                case 2: //center wall will be spwaned more often than the left and right wall
                    center();
                    break;
                case 3:
                    left();
                    break;
                case 4:
                    right();
                    break;

            }
            timer = delay;
        }

    }
}
